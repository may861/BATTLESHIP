using UnityEngine;

public class GridManager : MonoBehaviour
{

    public int width;
    public int height;
    public RectTransform GridPlace;
    public GameObject tilePrefab;
    public int tileSize = 40;
    public Tiles[,] tiles;
    public Tiles GetTile(int x, int y)
    {
        return tiles[x, y];
    }

    void Start()
    {
        GenerateGrid();
    }



    public void GenerateGrid()
    {
        float gridWidth = tileSize * width;
        float gridHeight = tileSize * height;

        //place grid in correct placement
        float offsetX = -gridWidth * GridPlace.pivot.x + tileSize / 2f;
        float offsetY = gridHeight * (1 - GridPlace.pivot.y) - tileSize / 2f;


        tiles = new Tiles[width, height];
        for (int row = 0; row < height; row++)
        {
            for (int col = 0; col < width; col++)
            {
                GameObject t = Instantiate(tilePrefab, GridPlace);
                RectTransform r = t.GetComponent<RectTransform>();
                r.anchoredPosition = new Vector2(offsetX + col * tileSize, offsetY - row * tileSize);        //place tile in correct placement
                Tiles myTile = r.GetComponent<Tiles>();

                if (myTile != null)
                {
                    tiles[row, col] = myTile;
                    myTile.TileX = row;
                    myTile.TileY = col;
                    myTile.shipManager = FindObjectOfType<ShipManager>();
                }
            }
        }

    }




    // for hints
    public int[,] BuildKnownMap()
    {
        int[,] known = new int[width, height];

        for (int x = 0; x < width; x++)
            for (int y = 0; y < height; y++)
            {
                Tiles t = tiles[x, y];
                if (t == null)
                {
                    known[x, y] = 0;
                    continue;
                }

                switch (t.state)
                {
                    case Tiles.TileState.Miss:
                        known[x, y] = 1;
                        break;

                    case Tiles.TileState.Hit:
                        known[x, y] = 2;
                        break;

                    default:
                        known[x, y] = 0; // Empty / Ship
                        break;
                }
            }

        return known;
    }
    public void DrawPlayingBoard()
    {
        for (int x = 0; x < width; x++)
            for (int y = 0; y < height; y++)
            {
                Tiles t = tiles[x, y];
                if (t == null) continue;

                switch (t.state)
                {
                    case Tiles.TileState.Hit:
                        t.SetTileColor(Color.red);
                        break;

                    case Tiles.TileState.Miss:
                        t.SetTileColor(Color.blue);
                        break;

                    default:
                        // Empty + Ship 
                        t.SetTileColor(new Color32(153, 217, 234, 255));
                        break;
                }
            }
    }
    public void DrawHintMap(int[,] hint)
    {
        for (int x = 0; x < width; x++)
            for (int y = 0; y < height; y++)
            {
                Tiles t = tiles[x, y];
                if (t == null) continue;

                switch (hint[x, y])
                {
                    case 0: t.SetTileColor(new Color32(153, 217, 234, 255)); break;
                    case 1: t.SetTileColor(Color.red); break;
                    case 2: t.SetTileColor(Color.blue); break;
                    case 3: t.SetTileColor(Color.white); break;
                    case 4: t.SetTileColor(Color.green); break;
                }
            }
    }

}


