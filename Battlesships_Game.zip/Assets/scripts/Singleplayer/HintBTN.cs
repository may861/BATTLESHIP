using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using UnityEngine;

public class HintBTN : MonoBehaviour
{
    public GridManager grid;
    public float hintDuration = 3f;

    public void OnHintClicked()
    {
        UnityEngine.Debug.Log("HintBTN was clicked");
        StartCoroutine(ShowHint());
    }

    IEnumerator ShowHint()
    {
        int[,] known = grid.BuildKnownMap();
        int[,] hint = HintAlgorithm.BuildHintMap(known);

        // show hint
        UnityEngine.Debug.Log("SHOW");
        grid.DrawHintMap(hint);

        yield return new WaitForSeconds(hintDuration);

        //hide hints
        UnityEngine.Debug.Log("HIDE");
        grid.DrawPlayingBoard();
    }

}
