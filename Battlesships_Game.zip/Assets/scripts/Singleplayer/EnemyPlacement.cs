using System.Collections.Generic;
using UnityEngine;

public class EnemyPlacement : MonoBehaviour
{
    public GridManager enemyGrid;
    public List<Ship> enemyShips;


    public void PlaceAllEnemyShips()
    {
        enemyShips = new List<Ship>()
        {
            new Ship() { ShipName = "CARRIER", ShipSize = 5 },
            new Ship() { ShipName = "BATTLESHIP", ShipSize = 4 },
            new Ship() { ShipName = "CRUISER", ShipSize = 3 },
            new Ship() { ShipName = "SUBMARINE", ShipSize = 3 },
            new Ship() { ShipName = "DESTROYER", ShipSize = 2 }
        };

        enemyGrid.GenerateGrid();

        foreach (Ship ship in enemyShips)
        {
            PlaceShipRandomly(ship);
        }
    }


    public void PlaceShipRandomly(Ship ship)
    {
        bool placed = false;
        int attempts = 0;

        while (!placed && attempts < 1000)
        {
            attempts++;

            bool horizontal = Random.value < 0.5f;
            int row = Random.Range(0, enemyGrid.height);
            int col = Random.Range(0, enemyGrid.width);

            if (CanPlaceShip(row, col, ship.ShipSize, horizontal))
            {
                ship.isHorizontal = horizontal;
                ship.positions.Clear();

                for (int i = 0; i < ship.ShipSize; i++)
                {
                    int r = row + (horizontal ? 0 : i);
                    int c = col + (horizontal ? i : 0);

                    Tiles tile = enemyGrid.GetTile(r, c);
                    tile.state = Tiles.TileState.Ship;
                    tile.ownerShip = ship;
                    ship.positions.Add(new Vector2Int(r, c));
                }

                placed = true;
            }
        }

        if (!placed)
            Debug.LogError($"FAILED to place {ship.ShipName}");
    }


    //public bool CanPlaceShip(int startRow, int startCol, int size, bool horizontal)
    //{
    //    for (int i = 0; i < size; i++)
    //    {
    //        int row = startRow;
    //        int col = startCol;

    //        if (horizontal) //if its horizontal see it this way
    //        {
    //            col += i;
    //        }

    //        else //if its not horizontal see it this way
    //        {
    //            row += i;
    //        }


    //        if (row < 0 || row >= enemyGrid.height || col < 0 || col >= enemyGrid.width)
    //        {
    //            return false;
    //        }

    //        if (enemyGrid.GetTile(row, col).state != Tiles.TileState.Empty) //if theres a ship there
    //        {
    //            return false;
    //        }


    //    }
    //    return true;
    //}



    public bool CanPlaceShip(int startRow, int startCol, int size, bool horizontal)
    {
        for (int i = 0; i < size; i++)
        {
            int row = startRow;
            int col = startCol;

            if (horizontal)
                col += i;
            else
                row += i;

            // Bounds check
            if (row < 0 || row >= enemyGrid.height || col < 0 || col >= enemyGrid.width)
                return false;

            // Tile itself must be empty
            if (enemyGrid.GetTile(row, col).state != Tiles.TileState.Empty)
                return false;

            // Check all surrounding tiles (including diagonals)
            for (int r = row - 1; r <= row + 1; r++)
            {
                for (int c = col - 1; c <= col + 1; c++)
                {
                    if (r < 0 || r >= enemyGrid.height || c < 0 || c >= enemyGrid.width)
                        continue;

                    if (enemyGrid.GetTile(r, c).state == Tiles.TileState.Ship)
                        return false;
                }
            }
        }

        return true;
    }


}
