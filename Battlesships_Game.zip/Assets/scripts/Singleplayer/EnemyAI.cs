using System.Collections.Generic;
using UnityEngine;

public class EnemyAI
{
    public enum AIMode { Hunt, Target }
    public AIMode mode = AIMode.Hunt;

    private List<Vector2Int> hits = new();

    public Vector2Int GetNextShot(GridManager grid)
    {
        return mode == AIMode.Hunt
            ? GetHuntShot(grid)
            : GetTargetShot(grid);
    }

    // ===================== HUNT =====================

    Vector2Int GetHuntShot(GridManager grid)
    {
        List<Vector2Int> options = new();

        for (int x = 0; x < grid.height; x++)
            for (int y = 0; y < grid.width; y++)
            {
                Tiles t = grid.GetTile(x, y);
                if (t.state == Tiles.TileState.Empty &&
                    (x + y) % 2 == 0)
                {
                    options.Add(new Vector2Int(x, y));
                }
            }

        return options[Random.Range(0, options.Count)];
    }

    // ===================== TARGET =====================

    Vector2Int GetTargetShot(GridManager grid)
    {
        if (hits.Count == 1)
            return FirstHitTarget(grid);

        return LineTarget(grid);
    }

    Vector2Int FirstHitTarget(GridManager grid)
    {
        Vector2Int h = hits[0];

        Vector2Int[] dirs =
        {
            Vector2Int.up,
            Vector2Int.down,
            Vector2Int.left,
            Vector2Int.right
        };

        foreach (var d in dirs)
        {
            Vector2Int p = h + d;
            if (IsValid(grid, p))
                return p;
        }

        Reset();
        return GetHuntShot(grid);
    }

    Vector2Int LineTarget(GridManager grid)
    {
        bool vertical = hits[0].x != hits[1].x;

        hits.Sort((a, b) =>
            vertical ? a.x.CompareTo(b.x) : a.y.CompareTo(b.y));

        Vector2Int start = hits[0];
        Vector2Int end = hits[^1];

        Vector2Int before = vertical
            ? new Vector2Int(start.x - 1, start.y)
            : new Vector2Int(start.x, start.y - 1);

        Vector2Int after = vertical
            ? new Vector2Int(end.x + 1, end.y)
            : new Vector2Int(end.x, end.y + 1);

        if (IsValid(grid, before)) return before;
        if (IsValid(grid, after)) return after;

        Reset();
        return GetHuntShot(grid);
    }

    bool IsValid(GridManager grid, Vector2Int p)
    {
        if (p.x < 0 || p.x >= grid.height ||
            p.y < 0 || p.y >= grid.width)
            return false;

        Tiles t = grid.GetTile(p.x, p.y);
        return t.state == Tiles.TileState.Empty;
    }

    // ===================== API =====================

    public void RegisterHit(Vector2Int p)
    {
        if (!hits.Contains(p))
            hits.Add(p);
        mode = AIMode.Target;
    }

    public void Reset()
    {
        hits.Clear();
        mode = AIMode.Hunt;
    }
}